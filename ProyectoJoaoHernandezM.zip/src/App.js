import logo from './logo.svg';
import './App.css';
import Home from './Home';
import Navbar from './Nav';

function App() {
  return (
    <div className="App">
      <Navbar />
      <br></br><br></br>
      <Home />
    </div>
  );
}

export default App;
